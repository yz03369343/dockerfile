OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Ne eblas malfari: %s",
    "Versions" : "Versioj",
    "Failed to revert {file} to revision {timestamp}." : "Malsukcesis returnigo de {file} al la revizio {timestamp}.",
    "Restore" : "Restaŭri",
    "No other versions available" : "Ne disponeblas aliaj versioj",
    "More versions..." : "Pli da versioj..."
},
"nplurals=2; plural=(n != 1);");

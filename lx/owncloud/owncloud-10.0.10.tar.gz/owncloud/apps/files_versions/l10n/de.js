OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Konnte %s nicht zurücksetzen",
    "Versions" : "Versionen",
    "Failed to revert {file} to revision {timestamp}." : "Konnte {file} der Revision {timestamp} nicht rückgängig machen.",
    "_%n byte_::_%n bytes_" : ["%n Byte","%n Bytes"],
    "Restore" : "Wiederherstellen",
    "No other versions available" : "Keine anderen Versionen verfügbar",
    "More versions..." : "Weitere Versionen…"
},
"nplurals=2; plural=(n != 1);");

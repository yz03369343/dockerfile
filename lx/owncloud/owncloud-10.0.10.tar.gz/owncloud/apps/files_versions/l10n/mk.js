OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Не можев да го вратам: %s",
    "Versions" : "Верзии",
    "Failed to revert {file} to revision {timestamp}." : "Не успеав да го вратам {file} на ревизијата {timestamp}.",
    "Restore" : "Врати",
    "No other versions available" : "Не постојат други верзии",
    "More versions..." : "Повеќе верзии..."
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");

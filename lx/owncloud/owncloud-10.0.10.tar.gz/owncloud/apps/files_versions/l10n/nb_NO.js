OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Klarte ikke å tilbakeføre: %s",
    "Versions" : "Versjoner",
    "Failed to revert {file} to revision {timestamp}." : "Klarte ikke å tilbakeføre {file} til revisjon {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n byte","%n bytes"],
    "Restore" : "Gjenopprett",
    "No other versions available" : "Det finnes ingen andre versjoner",
    "More versions..." : "Flere versjoner"
},
"nplurals=2; plural=(n != 1);");

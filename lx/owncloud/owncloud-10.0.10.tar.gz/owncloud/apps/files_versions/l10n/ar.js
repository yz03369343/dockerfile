OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "غير قادر على الاستعادة : %s",
    "Versions" : "الإصدارات",
    "Failed to revert {file} to revision {timestamp}." : "فشل في استعادة {ملف} لنتقيح {الطابع الزمني}",
    "Restore" : "استعادة ",
    "No other versions available" : "لا توجد إصدارات أخرى متاحة",
    "More versions..." : "المزيد من الإصدارات"
},
"nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;");

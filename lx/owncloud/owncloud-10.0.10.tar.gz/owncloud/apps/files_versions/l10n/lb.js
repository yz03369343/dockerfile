OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Konnt net zrécksetzen: %s",
    "Versions" : "Versiounen",
    "Failed to revert {file} to revision {timestamp}." : "Konnt {file} net op d'Versioun {timestamp} zrécksetzen.",
    "Restore" : "Zrécksetzen",
    "No other versions available" : "Keng aner Versiounen disponibel",
    "More versions..." : "Méi Versiounen..."
},
"nplurals=2; plural=(n != 1);");

OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Kon niet terugdraaien: %s",
    "Versions" : "Versies",
    "Failed to revert {file} to revision {timestamp}." : "Kon {file} niet terugdraaien naar revisie {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n byte","%n bytes"],
    "Restore" : "Herstellen",
    "No other versions available" : "Geen andere versies beschikbaar",
    "More versions..." : "Meer versies..."
},
"nplurals=2; plural=(n != 1);");

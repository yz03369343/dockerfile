OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Palautus epäonnistui: %s",
    "Versions" : "Versiot",
    "Failed to revert {file} to revision {timestamp}." : "Tiedoston {file} palautus versioon {timestamp} epäonnistui.",
    "_%n byte_::_%n bytes_" : ["%n tavu","%n tavua"],
    "Restore" : "Palauta",
    "No other versions available" : "Ei muita versioita saatavilla",
    "More versions..." : "Lisää versioita..."
},
"nplurals=2; plural=(n != 1);");

OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Non foi posíbel reverter: %s",
    "Versions" : "Versións",
    "Failed to revert {file} to revision {timestamp}." : "Non foi posíbel reverter {file} á revisión {timestamp}.",
    "Restore" : "Restabelecer",
    "No other versions available" : "Non hai outras versións dispoñíbeis",
    "More versions..." : "Máis versións..."
},
"nplurals=2; plural=(n != 1);");

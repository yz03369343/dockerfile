OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Nemožno obnoviť: %s",
    "Versions" : "Verzie",
    "Failed to revert {file} to revision {timestamp}." : "Zlyhalo obnovenie súboru {file} na verziu {timestamp}.",
    "Restore" : "Obnoviť",
    "No other versions available" : "Žiadne ďalšie verzie nie sú dostupné",
    "More versions..." : "Viac verzií..."
},
"nplurals=3; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2;");

OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "ಹಿಂತಿರುಗಲಾಗಲಿಲ್ಲ: %s",
    "Versions" : "ಆವೃತ್ತಿಗಳು",
    "Failed to revert {file} to revision {timestamp}." : "{timestamp} ದ ಪರಿಷ್ಕರಣೆ ಇಂದ  {file}  ಕಡತವನ್ನು ಹಿಂದಿರುಗಿಸಲು ವಿಫಲವಾಗಿದೆ.",
    "Restore" : "ಮರುಸ್ಥಾಪಿಸು",
    "No other versions available" : "ಇನ್ನಿತರೆ ಯಾವುದೇ ಆವೃತ್ತಿಗಳು ಲಭ್ಯವಿಲ್ಲ",
    "More versions..." : "ಇನ್ನಷ್ಟು ಆವೃತ್ತಿಗಳು ..."
},
"nplurals=1; plural=0;");

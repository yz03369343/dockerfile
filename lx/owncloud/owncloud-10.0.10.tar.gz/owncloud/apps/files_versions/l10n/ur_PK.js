OC.L10N.register(
    "files_versions",
    {
    "Restore" : "بحال"
},
"nplurals=2; plural=(n != 1);");

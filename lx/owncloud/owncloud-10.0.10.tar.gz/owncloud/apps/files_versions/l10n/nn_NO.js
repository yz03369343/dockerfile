OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Klarte ikkje å tilbakestilla: %s",
    "Versions" : "Utgåver",
    "Failed to revert {file} to revision {timestamp}." : "Klarte ikkje å tilbakestilla {file} til utgåva {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n byte","%n byte"],
    "Restore" : "Gjenopprett",
    "No other versions available" : "Ingen andre utgåver tilgjengeleg",
    "More versions..." : "Fleire utgåver …"
},
"nplurals=2; plural=(n != 1);");

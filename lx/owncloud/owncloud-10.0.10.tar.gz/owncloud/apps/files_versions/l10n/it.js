OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Impossibile ripristinare: %s",
    "Versions" : "Versioni",
    "Failed to revert {file} to revision {timestamp}." : "Ripristino di {file} alla revisione {timestamp} non riuscito.",
    "_%n byte_::_%n bytes_" : ["%n byte","%n byte"],
    "Restore" : "Ripristina",
    "No other versions available" : "Non sono disponibili altre versioni",
    "More versions..." : "Altre versioni..."
},
"nplurals=2; plural=(n != 1);");

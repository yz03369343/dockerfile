OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "ვერ მოხერხდა უკან დაბრუნება: %s",
    "Versions" : "ვერსიები",
    "Restore" : "აღდგენა"
},
"nplurals=1; plural=0;");

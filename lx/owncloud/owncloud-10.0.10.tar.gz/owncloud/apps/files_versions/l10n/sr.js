OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Не могу да вратим: %s",
    "Versions" : "Верзије",
    "Failed to revert {file} to revision {timestamp}." : "Не могу да вратим {file} на ревизију {timestamp}.",
    "Restore" : "Врати",
    "No other versions available" : "Нема других верзија",
    "More versions..." : "Још верзија..."
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");

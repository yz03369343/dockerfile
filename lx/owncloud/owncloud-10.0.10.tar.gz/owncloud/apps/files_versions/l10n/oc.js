OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Impossible de restablir %s",
    "Versions" : "Versions",
    "Failed to revert {file} to revision {timestamp}." : "Fracàs del retorn del fichièr {file} a la revision {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n octet","%n octets"],
    "Restore" : "Restablir",
    "No other versions available" : "Cap d'autra version es pas disponibla",
    "More versions..." : "Mai de versions..."
},
"nplurals=2; plural=(n > 1);");

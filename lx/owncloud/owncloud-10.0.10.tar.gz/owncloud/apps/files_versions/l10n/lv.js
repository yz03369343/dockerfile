OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Nevarēja atgriezt — %s",
    "Versions" : "Versijas",
    "Failed to revert {file} to revision {timestamp}." : "Neizdevās atjaunot {file} no rediģējuma {timestamp} ",
    "Restore" : "Atjaunot",
    "No other versions available" : "Citas versijas nav pieejamas",
    "More versions..." : "Vairāk versiju..."
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");

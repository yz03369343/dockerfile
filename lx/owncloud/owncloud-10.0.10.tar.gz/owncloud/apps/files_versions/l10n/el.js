OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Αδυναμία επαναφοράς: %s",
    "Versions" : "Εκδόσεις",
    "Failed to revert {file} to revision {timestamp}." : "Αποτυχία επαναφοράς του {file} στην αναθεώρηση {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n byte","%n bytes"],
    "Restore" : "Επαναφορά",
    "No other versions available" : "Δεν υπάρχουν άλλες εκδόσεις διαθέσιμες",
    "More versions..." : "Περισσότερες εκδόσεις..."
},
"nplurals=2; plural=(n != 1);");

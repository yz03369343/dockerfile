OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "No se puede revertir: %s",
    "Versions" : "Revisiones",
    "Failed to revert {file} to revision {timestamp}." : "No se ha podido revertir {archivo} a revisión {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n byte","%n bytes"],
    "Restore" : "Recuperar",
    "No other versions available" : "No hay otras versiones disponibles",
    "More versions..." : "Más versiones..."
},
"nplurals=2; plural=(n != 1);");

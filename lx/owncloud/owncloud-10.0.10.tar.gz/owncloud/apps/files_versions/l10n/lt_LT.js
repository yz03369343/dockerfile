OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Nepavyko atstatyti: %s",
    "Versions" : "Versijos",
    "Failed to revert {file} to revision {timestamp}." : "Nepavyko atstatyti {file} į būseną {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n baitas","%n baitai","%n baitų"],
    "Restore" : "Atstatyti",
    "No other versions available" : "Nėra daugiau versijų",
    "More versions..." : "Daugiau versijų..."
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && (n%100<10 || n%100>=20) ? 1 : 2);");

OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Грешка при връщане: %s",
    "Versions" : "Версии",
    "Failed to revert {file} to revision {timestamp}." : "Грешка при връщане на {file} към версия {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n байт","%n байта"],
    "Restore" : "Възтановяви",
    "No other versions available" : "Няма други налични версии",
    "More versions..." : "Още версии..."
},
"nplurals=2; plural=(n != 1);");

OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Не вдалося відновити: %s",
    "Versions" : "Версії",
    "Failed to revert {file} to revision {timestamp}." : "Не вдалося відновити {file} до ревізії {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n байт","%n байт","%n байт"],
    "Restore" : "Відновити",
    "No other versions available" : "Інші версії недоступні",
    "More versions..." : "Більше версій ..."
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");

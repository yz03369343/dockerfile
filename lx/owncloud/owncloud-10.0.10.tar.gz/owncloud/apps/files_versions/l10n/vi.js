OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Không thể khôi phục: %s",
    "Versions" : "Phiên bản",
    "Failed to revert {file} to revision {timestamp}." : "Thất bại khi trở lại {file} khi sử đổi {timestamp}.",
    "Restore" : "Khôi phục",
    "No other versions available" : "Không có các phiên bản khác có sẵn",
    "More versions..." : "Nhiều phiên bản ..."
},
"nplurals=1; plural=0;");

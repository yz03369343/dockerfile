OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Nu s-a putut reveni: %s",
    "Versions" : "Versiuni",
    "Failed to revert {file} to revision {timestamp}." : "S-a eșuat restaurarea fișierului  {file} la revizia {timestamp}.",
    "Restore" : "Restaurare",
    "No other versions available" : "Nu există alte versiuni disponibile",
    "More versions..." : "Mai multe versiuni..."
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");

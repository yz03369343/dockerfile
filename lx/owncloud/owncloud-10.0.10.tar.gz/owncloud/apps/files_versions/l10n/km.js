OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "មិន​អាច​ត្រឡប់៖ %s",
    "Versions" : "កំណែ",
    "Failed to revert {file} to revision {timestamp}." : "មិន​អាច​ត្រឡប់ {file} ទៅ​កំណែ​សម្រួល {timestamp} បាន​ទេ។",
    "Restore" : "ស្ដារ​មក​វិញ",
    "No other versions available" : "មិន​មាន​កំណែ​ផ្សេង​ទៀត​ទេ",
    "More versions..." : "កំណែ​ច្រើន​ទៀត..."
},
"nplurals=1; plural=0;");

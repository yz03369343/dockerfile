OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Geri alınamayan: %s",
    "Versions" : "Sürümler",
    "Failed to revert {file} to revision {timestamp}." : "{file} dosyası {timestamp} gözden geçirmesine geri alınamadı.",
    "Restore" : "Geri yükle",
    "No other versions available" : "Başka sürüm mevcut değil",
    "More versions..." : "Daha fazla sürüm..."
},
"nplurals=2; plural=(n > 1);");

OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "ئەسلىگە قايتۇرالمايدۇ: %s",
    "Versions" : "نەشرى"
},
"nplurals=1; plural=0;");

OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "無法還原：%s",
    "Versions" : "版本",
    "Failed to revert {file} to revision {timestamp}." : "無法還原檔案 {file} 至版本 {timestamp}",
    "_%n byte_::_%n bytes_" : ["%n 位元"],
    "Restore" : "復原",
    "No other versions available" : "沒有其他版本了",
    "More versions..." : "更多版本…"
},
"nplurals=1; plural=0;");

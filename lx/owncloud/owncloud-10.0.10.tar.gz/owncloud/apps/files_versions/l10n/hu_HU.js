OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Nem sikerült átállni a változatra: %s",
    "Versions" : "Az állományok korábbi változatai",
    "Failed to revert {file} to revision {timestamp}." : "Nem sikerült a(z) {file} állományt erre visszaállítani: {timestamp}.",
    "Restore" : "Visszaállítás",
    "No other versions available" : "Az állománynak nincs több változata",
    "More versions..." : "További változatok..."
},
"nplurals=2; plural=(n != 1);");

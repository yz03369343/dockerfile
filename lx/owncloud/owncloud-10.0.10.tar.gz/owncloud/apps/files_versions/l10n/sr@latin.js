OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Ne mogu da vratim: %s",
    "Versions" : "Verzije",
    "Failed to revert {file} to revision {timestamp}." : "Ne mogu da vratim {file} na reviziju {timestamp}.",
    "Restore" : "Vrati",
    "No other versions available" : "Nema drugih verzija",
    "More versions..." : "Još verzija..."
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");

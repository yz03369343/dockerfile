OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "S’u rikthye dot: %s",
    "Versions" : "Versione",
    "Failed to revert {file} to revision {timestamp}." : "Dështoi në rikthimin e {file} te rishikimi {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n bajt","%n bajte"],
    "Restore" : "Riktheje",
    "No other versions available" : "Nuk ka versione të tjera të gatshme",
    "More versions..." : "Më shumë versione…"
},
"nplurals=2; plural=(n != 1);");

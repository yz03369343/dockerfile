OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "بازگردانی امکان ناپذیر است: %s",
    "Versions" : "نسخه‌ها",
    "Failed to revert {file} to revision {timestamp}." : "برگرداندن {file} به نسخه {timestamp} با شکست روبرو شد",
    "_%n byte_::_%n bytes_" : ["%n بایت"],
    "Restore" : "بازیابی",
    "No other versions available" : "نسخه‌ی دیگری در دسترس نیست",
    "More versions..." : "نسخه‌های بیشتر"
},
"nplurals=1; plural=0;");

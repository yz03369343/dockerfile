OC.L10N.register(
    "files_versions",
    {
    "Versions" : "Տարբերակներ",
    "_%n byte_::_%n bytes_" : ["%n բայտ","%n բայտ"],
    "Restore" : "Վերականգնել",
    "No other versions available" : "Այլ տարբերակներ չկան",
    "More versions..." : "Ավել տարբերակներ..."
},
"nplurals=2; plural=(n != 1);");

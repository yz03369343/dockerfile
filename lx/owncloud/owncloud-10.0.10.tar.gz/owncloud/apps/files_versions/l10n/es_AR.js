OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "No se pudo revertir: %s ",
    "Versions" : "Versiones",
    "Failed to revert {file} to revision {timestamp}." : "Falló al revertir {file} a la revisión {timestamp}.",
    "Restore" : "Recuperar",
    "No other versions available" : "No hay más versiones disponibles",
    "More versions..." : "Más versiones..."
},
"nplurals=2; plural=(n != 1);");

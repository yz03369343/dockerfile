OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Nun pudo revertise: %s",
    "Versions" : "Versiones",
    "Failed to revert {file} to revision {timestamp}." : "Fallu al revertir {file} a la revisión {timestamp}.",
    "Restore" : "Restaurar",
    "No other versions available" : "Nun hai otres versiones disponibles",
    "More versions..." : "Más versiones..."
},
"nplurals=2; plural=(n != 1);");

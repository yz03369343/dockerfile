OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Tidak dapat kembalikan: %s",
    "Versions" : "Versi",
    "Failed to revert {file} to revision {timestamp}." : "Gagal kembalikan {file} ke semakan {timestamp}.",
    "Restore" : "Pulihkan",
    "No other versions available" : "Tiada lagi versi lain",
    "More versions..." : "Lagi versi..."
},
"nplurals=1; plural=0;");

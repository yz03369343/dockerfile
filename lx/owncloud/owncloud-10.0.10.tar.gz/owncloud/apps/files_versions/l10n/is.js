OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Gat ekki endurheimt: %s",
    "Versions" : "Útgáfur",
    "Failed to revert {file} to revision {timestamp}." : "Mistókst að endurheimta {file} útgáfu {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n bæti","%n bæti"],
    "Restore" : "Endurheimta",
    "No other versions available" : "Engar aðrar útgáfur í boði",
    "More versions..." : "Fleiri útgáfur..."
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");

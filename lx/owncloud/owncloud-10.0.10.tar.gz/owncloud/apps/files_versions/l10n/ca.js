OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "No s'ha pogut revertir: %s",
    "Versions" : "Versions",
    "Failed to revert {file} to revision {timestamp}." : "Ha fallat en retornar {file} a la revisió {timestamp}",
    "Restore" : "Recupera",
    "No other versions available" : "No hi ha altres versions disponibles",
    "More versions..." : "Més versions..."
},
"nplurals=2; plural=(n != 1);");

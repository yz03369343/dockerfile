OC.L10N.register(
    "files_versions",
    {
    "Versions" : "பதிப்புகள்"
},
"nplurals=2; plural=(n != 1);");

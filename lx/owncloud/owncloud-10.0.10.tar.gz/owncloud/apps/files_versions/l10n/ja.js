OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "元に戻せませんでした: %s",
    "Versions" : "バージョン",
    "Failed to revert {file} to revision {timestamp}." : "{file} を {timestamp} のリビジョンに戻すことができません。",
    "_%n byte_::_%n bytes_" : ["%n バイト"],
    "Restore" : "復元",
    "No other versions available" : "利用可能なバージョンはありません",
    "More versions..." : "他のバージョン..."
},
"nplurals=1; plural=0;");

OC.L10N.register(
    "files_versions",
    {
    "Versions" : "وه‌شان"
},
"nplurals=2; plural=(n != 1);");

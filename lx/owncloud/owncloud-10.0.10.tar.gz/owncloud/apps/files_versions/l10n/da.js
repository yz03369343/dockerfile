OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Kunne ikke genskabe: %s",
    "Versions" : "Versioner",
    "Failed to revert {file} to revision {timestamp}." : "Kunne ikke tilbagerulle {file} til den tidligere udgave: {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n byte","%n bytes"],
    "Restore" : "Gendan",
    "No other versions available" : "Ingen andre versioner tilgængelig",
    "More versions..." : "Flere versioner..."
},
"nplurals=2; plural=(n != 1);");

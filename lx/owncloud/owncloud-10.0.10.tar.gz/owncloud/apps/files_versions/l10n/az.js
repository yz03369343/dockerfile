OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Geri qaytarmaq olmur: %s",
    "Versions" : "Versiyaları",
    "Failed to revert {file} to revision {timestamp}." : "{timestamp} yenidən baxılması üçün {file} geri qaytarmaq mümkün olmadı.",
    "Restore" : "Geri qaytar",
    "No other versions available" : "Başqa versiyalar mövcud deyil",
    "More versions..." : "Əlavə versiyalar"
},
"nplurals=2; plural=(n != 1);");

OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "无法恢复: %s",
    "Versions" : "版本",
    "Failed to revert {file} to revision {timestamp}." : "无法恢复 {file} 到 {timestamp} 的版本。",
    "_%n byte_::_%n bytes_" : ["%n 字节"],
    "Restore" : "恢复",
    "No other versions available" : "无其他版本可用",
    "More versions..." : "更多版本..."
},
"nplurals=1; plural=0;");

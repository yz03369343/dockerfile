OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "되돌릴 수 없습니다: %s",
    "Versions" : "버전",
    "Failed to revert {file} to revision {timestamp}." : "{file}을(를) 리비전 {timestamp}으(로) 되돌리는 데 실패했습니다.",
    "_%n byte_::_%n bytes_" : ["%n 바이트"],
    "Restore" : "복원",
    "No other versions available" : "다른 버전을 사용할 수 없습니다",
    "More versions..." : "더 많은 버전..."
},
"nplurals=1; plural=0;");

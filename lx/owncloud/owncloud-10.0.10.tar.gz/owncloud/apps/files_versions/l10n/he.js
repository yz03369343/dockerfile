OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "לא ניתן להחזיר: %s",
    "Versions" : "גרסאות",
    "Failed to revert {file} to revision {timestamp}." : "נכשל אחזור {file} לגרסה {timestamp}.",
    "_%n byte_::_%n bytes_" : ["%n ביט","%n ביטים"],
    "Restore" : "שחזור",
    "No other versions available" : "אין גרסאות אחרות זמינות",
    "More versions..." : "גרסאות נוספות..."
},
"nplurals=2; plural=(n != 1);");

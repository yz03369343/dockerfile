OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "ไม่สามารถย้อนกลับ: %s",
    "Versions" : "รุ่น",
    "Failed to revert {file} to revision {timestamp}." : "{file} ล้มเหลวที่จะย้อนกลับ มีการแก้ไขเมื่อ {timestamp}",
    "_%n byte_::_%n bytes_" : ["%n ไบต์"],
    "Restore" : "กู้คืน",
    "No other versions available" : "ยังไม่มีรุ่นที่ใหม่กว่า",
    "More versions..." : "รุ่นอื่นๆ ..."
},
"nplurals=1; plural=0;");

OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "ফিরে যাওয়া গেলনা: %s",
    "Versions" : "সংষ্করন",
    "Failed to revert {file} to revision {timestamp}." : " {file} সংশোধিত  {timestamp} এ ফিরে যেতে ব্যার্থ হলো।",
    "Restore" : "ফিরিয়ে দাও",
    "No other versions available" : "আর কোন সংষ্করণ প্রাপ্তব্য নয়",
    "More versions..." : "আরো সংষ্করণ...."
},
"nplurals=2; plural=(n != 1);");

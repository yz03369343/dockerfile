OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "প্রত্যাবর্তন করা যায়নি: %s",
    "Versions" : "সংস্করণ",
    "Failed to revert {file} to revision {timestamp}." : "{ফাইল} প্রত্যাবর্তন থেকে পুনর্বিবেচনা {টাইমস্ট্যাম্প} করতে ব্যর্থ।",
    "Restore" : "পুনরুদ্ধার",
    "No other versions available" : "আর কোন সংস্করণ পাওয়া যাচ্ছে না",
    "More versions..." : "আরো সংস্করণ..."
},
"nplurals=2; plural=(n != 1);");

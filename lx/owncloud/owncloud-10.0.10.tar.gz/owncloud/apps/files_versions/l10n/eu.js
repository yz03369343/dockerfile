OC.L10N.register(
    "files_versions",
    {
    "Could not revert: %s" : "Ezin izan da leheneratu: %s",
    "Versions" : "Bertsioak",
    "Failed to revert {file} to revision {timestamp}." : "Errore bat izan da {fitxategia} {timestamp} bertsiora leheneratzean.",
    "Restore" : "Berrezarri",
    "No other versions available" : "Ez dago bertsio gehiago eskuragarri",
    "More versions..." : "Bertsio gehiago..."
},
"nplurals=2; plural=(n != 1);");

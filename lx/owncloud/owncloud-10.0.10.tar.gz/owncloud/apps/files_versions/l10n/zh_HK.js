OC.L10N.register(
    "files_versions",
    {
    "Versions" : "版本"
},
"nplurals=1; plural=0;");

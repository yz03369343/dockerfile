OC.L10N.register(
    "files_sharing",
    {
    "Uploading..." : "பதிவேற்றல்...",
    "Cancel" : "இரத்து செய்க",
    "Share" : "பகிர்வு",
    "Password" : "கடவுச்சொல்",
    "Name" : "பெயர்",
    "Expiration date" : "காலவதியாகும் திகதி",
    "Download" : "பதிவிறக்குக",
    "Pending" : "நிலுவையிலுள்ள"
},
"nplurals=2; plural=(n != 1);");

OC.L10N.register(
    "files_sharing",
    {
    "Uploading..." : "يۈكلەۋاتىدۇ…",
    "Cancel" : "ۋاز كەچ",
    "Share" : "ھەمبەھىر",
    "Shared by" : "ھەمبەھىرلىگۈچى",
    "Sharing" : "ھەمبەھىر",
    "Password" : "ئىم",
    "Name" : "ئاتى",
    "Download" : "چۈشۈر",
    "Pending" : "كۈتۈۋاتىدۇ"
},
"nplurals=1; plural=0;");

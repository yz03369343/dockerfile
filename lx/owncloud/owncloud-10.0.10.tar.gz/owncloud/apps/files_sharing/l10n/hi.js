OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "रद्द करें ",
    "Share" : "साझा करें",
    "Shared by" : "द्वारा साझा",
    "Password" : "पासवर्ड",
    "Declined" : "अस्वीकार कर दिया गया "
},
"nplurals=2; plural=(n != 1);");

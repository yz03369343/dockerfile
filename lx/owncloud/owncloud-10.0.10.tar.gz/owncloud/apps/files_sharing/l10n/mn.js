OC.L10N.register(
    "files_sharing",
    {
    "Share" : "Түгээх",
    "Sharing" : "Түгээлт",
    "A file or folder has been <strong>shared</strong>" : "Файл эсвэл хавтас амжилттай <strong>түгээгдлээ</strong>",
    "You shared %1$s with %2$s" : "Та %1$s-ийг %2$s руу түгээлээ",
    "You shared %1$s with group %2$s" : "Та %1$s-ийг %2$s групп руу түгээлээ",
    "You shared %1$s via link" : "Та %1$s-ийг холбоосоор түгээлээ",
    "%2$s shared %1$s with you" : "%2$s %1$s-ийг тань руу түгээлээ",
    "Shares" : "Түгээлтүүд",
    "Password" : "Нууц үг",
    "Cancel" : "Цуцлах"
},
"nplurals=2; plural=(n != 1);");

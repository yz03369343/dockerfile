OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "Abbrechen",
    "Invalid ownCloud url" : "Fehlerhafte ownCloud URL",
    "Share" : "Teilen",
    "The password is wrong. Try again." : "Dieses Passwort ist falsch. Bitte versuche es erneut.",
    "Password" : "Passwort",
    "Name" : "Name",
    "Expiration date" : "Auslaufdatum",
    "Add to your ownCloud" : "Zu deiner ownCloud hinzufügen",
    "Download" : "Download"
},
"nplurals=2; plural=(n != 1);");

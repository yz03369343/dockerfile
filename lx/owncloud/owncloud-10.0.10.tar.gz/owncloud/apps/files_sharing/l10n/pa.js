OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "ਰੱਦ ਕਰੋ",
    "Share" : "ਸਾਂਝਾ ਕਰੋ",
    "Sharing" : "ਸਾਂਝ",
    "Password" : "ਪਾਸਵਰ",
    "Download" : "ਡਾਊਨਲੋਡ"
},
"nplurals=2; plural=(n != 1);");

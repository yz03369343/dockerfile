OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "రద్దుచేయి",
    "Password" : "సంకేతపదం",
    "Name" : "పేరు",
    "Expiration date" : "కాలం చెల్లు తేదీ"
},
"nplurals=2; plural=(n != 1);");

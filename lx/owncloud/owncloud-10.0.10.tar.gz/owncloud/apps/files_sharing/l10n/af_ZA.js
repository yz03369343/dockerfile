OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "Kanseleer",
    "Share" : "Deel",
    "Password" : "Wagwoord",
    "Expiration date" : "Verval datum",
    "Sharing" : "Deling",
    "This share is password-protected" : "Hierdie deling word met ’n wagwoord beskerm",
    "No entries found in this folder" : "Geen inskrywings in hierdie vouer gevind",
    "Name" : "Naam",
    "the item was removed" : "die item is verwyder",
    "sharing is disabled" : "deling is gedeaktiveer",
    "Download" : "Laai Af",
    "Download %s" : "Laai %s Af",
    "Uploading..." : "Laai tans op…",
    "The password is wrong. Try again." : "ie wagwoord is verkeerd. Probeer weer.",
    "Reasons might be:" : "Moontlike redes is:",
    "Pending" : "Hangend",
    "Accept" : "Aanvaar",
    "Decline" : "Verwerp"
},
"nplurals=2; plural=(n != 1);");

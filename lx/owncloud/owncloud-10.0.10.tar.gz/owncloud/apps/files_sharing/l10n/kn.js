OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "﻿ರದ್ದು",
    "Share" : "﻿ಹಂಚಿಕೊಳ್ಳಿ",
    "Sharing" : "﻿ಹಂಚಿಕೆ",
    "Password" : "ಗುಪ್ತ ಪದ",
    "Name" : "﻿ಹೆಸರು",
    "Expiration date" : "ಮುಕ್ತಾಯ ದಿನಾಂಕ",
    "Download" : "ಪ್ರತಿಯನ್ನು ಸ್ಥಳೀಯವಾಗಿ ಉಳಿಸಿಕೊಳ್ಳಿ",
    "Pending" : "﻿ಬಾಕಿ ಇದೆ"
},
"nplurals=1; plural=0;");

OC.L10N.register(
    "files_sharing",
    {
    "Uploading..." : "მიმდინარეობს ატვირთვა...",
    "Cancel" : "უარყოფა",
    "Share" : "გაზიარება",
    "Shared by" : "აზიარებს",
    "Sharing" : "გაზიარება",
    "Password" : "პაროლი",
    "Name" : "სახელი",
    "Expiration date" : "ვადის გასვლის დრო",
    "Download" : "ჩამოტვირთვა",
    "Pending" : "მოცდის რეჟიმში"
},
"nplurals=1; plural=0;");

OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "ပယ်ဖျက်မည်",
    "Password" : "စကားဝှက်",
    "Expiration date" : "သက်တမ်းကုန်ဆုံးမည့်ရက်",
    "Download" : "ဒေါင်းလုတ်"
},
"nplurals=1; plural=0;");

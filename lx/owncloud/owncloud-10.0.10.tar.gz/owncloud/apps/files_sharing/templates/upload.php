<?php

script('files', 'file-upload');
script('files_sharing', 'PublicUploadView');
style('files_sharing', 'upload');

?>
<div id='notification'></div>

<div class="uploadForm"></div>

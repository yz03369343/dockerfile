<?php
$TRANSLATIONS = array(
"Documentation" => "Dokumentasi"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";

// Exports the "insertdatetime" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/insertdatetime')
//   ES2015:
//     import 'tinymce/plugins/insertdatetime'
require('./plugin.js');